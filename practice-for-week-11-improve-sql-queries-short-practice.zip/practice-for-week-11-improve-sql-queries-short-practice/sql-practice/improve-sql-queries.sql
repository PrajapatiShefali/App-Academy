----------
-- Step 0 - Create a Query 
----------
-- Query: Select all cats that have a toy with an id of 5

    -- Your code here

drop table  if exists cats_toys_id;
create table cats_toys_id (
    name varchar(50)
);
-- EXPLAIN QUERY PLAN
insert into cats_toys_id(name)
select cats.name 
from cats join cat_toys  
on cats.id=cat_toys.cat_id 
join toys on toys.id=cat_toys.toy_id
where toys.id=5;

-- Paste your results below (as a comment):


---Carlene

----------
-- Step 1 - Analyze the Query
----------
-- Query:
-- 1. It is searching for the records with specific id
-- 2. indexes
---3. cats followed by toys
    -- Your code here

-- Paste your results below (as a comment):
-- 0|0|0|SEARCH TABLE cats USING INTEGER PRIMARY KEY (rowid=?)
-- 0|1|1|SEARCH TABLE toys USING INTEGER PRIMARY KEY (rowid=?)

-- What do your results mean?

    -- Was this a SEARCH or SCAN?
-- SEARCH

    -- What does that mean?




----------
-- Step 2 - Time the Query to get a baseline
----------
-- Query (to be used in the sqlite CLI):

    -- Your code here

-- Paste your results below (as a comment):




----------
-- Step 3 - Add an index and analyze how the query is executing
----------

-- Create index:
create index index_cats_toys_id_name on cats_toys_id(name);
    -- Your code here

-- Analyze Query:
    -- Your code here

-- Paste your results below (as a comment):


-- Analyze Results:

    -- Is the new index being applied in this query?


select cats.name 
cats_toys_id 
from cats join toys 
on cats.id=toys.id 
where toys.id=5;

----------
-- Step 4 - Re-time the query using the new index
----------
-- Query (to be used in the sqlite CLI):

    -- Your code here

-- Paste your results below (as a comment):


-- Analyze Results:
    -- Are you still getting the correct query results?


    -- Did the execution time improve (decrease)?


    -- Do you see any other opportunities for making this query more efficient?


---------------------------------
-- Notes From Further Exploration
---------------------------------