-- Find the name of the cats co-owned 
--by both George Beatty and Melynda Abshire
-- Your code here

select name
from cats
where id in (
                select DISTINCT cat_id from cat_owners
                where owner_id=
                    (select id from owners 
                    where (first_name like 'George' and last_name like 'Beatty'))
            )
            
and id in (
    select DISTINCT cat_id from cat_owners 
                where owner_id=
                    (select id from owners 
                    where (first_name like 'Melynda' and last_name like 'Abshire'))
);