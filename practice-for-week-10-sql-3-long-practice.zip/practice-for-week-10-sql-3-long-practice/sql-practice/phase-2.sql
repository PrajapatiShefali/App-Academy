-- Using subqueries, find the names of the cats whose owners 
--are either George Beatty or Melynda Abshire
-- Your code here

select cats.name
from cats
where id in (
                select cat_id from cat_owners
                where owner_id in 
                (
                    select id from owners 
                    where (first_name like 'George' and last_name like 'Beatty')
                    or  (first_name like 'Melynda' and last_name like 'Abshire')
                )
            );

SELECT DISTINCT cats.name
FROM cats
JOIN cat_owners ON cats.id = cat_owners.cat_id
JOIN owners ON owners.id = cat_owners.owner_id
WHERE (owners.first_name = 'George' AND owners.last_name = 'Beatty') 
   OR (owners.first_name = 'Melynda' AND owners.last_name = 'Abshire');