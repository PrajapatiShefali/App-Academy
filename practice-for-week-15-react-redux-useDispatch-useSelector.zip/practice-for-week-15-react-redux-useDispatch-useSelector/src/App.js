import ArticleList from './components/ArticleList';
import './App.css';

function App() {
  return (
    <div>
      <ArticleList />
    </div>
  );
}

export default App;
