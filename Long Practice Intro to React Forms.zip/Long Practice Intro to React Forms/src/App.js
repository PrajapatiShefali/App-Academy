import ContactUsBonus from './ContactUsBonus';

function App() {
  return (
    <ContactUsBonus />
  );
}

export default App;