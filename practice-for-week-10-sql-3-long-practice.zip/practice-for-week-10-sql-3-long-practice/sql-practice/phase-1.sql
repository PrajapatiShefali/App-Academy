--Insert new cat named "Red" born this year
-- Your code here
insert into cats (name,birth_year)
VALUES
("Red",2024);

--Assign ownership of new cat to George Beatty using subqueries
-- Your code here
insert into cat_owners (cat_id,owner_id)
select 
 (select id from cats where name like 'Red' limit 1) as cat_id ,
 (select id from owners where first_name like 'George'
  and last_name like 'Beatty' limit 1) as owner_id;

--Query to verify INSERTs worked properly
-- Your code here

select * from cats 
join cat_owners 
on cat_id=cats.id 
join owners on owners.id=owner_id where cats.name like 'Red';

