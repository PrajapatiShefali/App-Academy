# Long Practice: SQL with JOIN Tables

In this project, you will be executing SQL commands with JOIN tables.

## Set up

* Run `npm install` to install the dependencies.
* Run all the tests with `npm test`
