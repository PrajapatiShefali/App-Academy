function App() {
  return (
    <div>
      <h1>App Component</h1>
    </div>
  );
}

export default App;