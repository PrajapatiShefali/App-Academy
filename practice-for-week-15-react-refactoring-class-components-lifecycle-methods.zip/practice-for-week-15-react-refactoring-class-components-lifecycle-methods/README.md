# Code for Lifecycle Method Videos

To access the code that is used in the Lifecycle Method videos, click the
`Download Project` button at the bottom of this page and load the repo into
[CodeSandbox].

[CodeSandbox]: https://www.codesandbox.io