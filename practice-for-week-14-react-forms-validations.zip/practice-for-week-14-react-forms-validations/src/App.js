import ContactUs from './ContactUs';

function App() {
  return (
    <ContactUs />
  );
}

export default App;