-- Find the name and birth year of all the cats ordered
-- by descending birth year
-- Your code here

select name,birth_year
from cats 
order by birth_year DESC;