-- Find Hermione's cats
-- Your code here
-- select cats.name 
-- from cats join cat_owners
-- on cats.id=cat_owners.cat_id
-- where owner_id=(select id from owners where first_name like 'Hermione')


select cats.name 
from cats join cat_owners
on cats.id=cat_owners.cat_id
join owners
on owners.id=cat_owners.owner_id
where owners.first_name like 'Hermione';