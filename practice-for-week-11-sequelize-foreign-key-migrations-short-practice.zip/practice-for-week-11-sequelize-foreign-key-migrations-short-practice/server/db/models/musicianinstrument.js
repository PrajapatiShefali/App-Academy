'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class MusicianInstrument extends Model {
    static associate(models) {
      // define association here
    }
  }
  MusicianInstrument.init({
    musicianId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Musicians',
        key: 'id'
      },
      onDelete: 'CASCADE',
      primaryKey: true
    },
    instrumentId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Instruments',
        key: 'id'
      },
      onDelete: 'CASCADE',
      primaryKey: true
    }
  }, {
    sequelize,
    modelName: 'MusicianInstrument',
  });
  return MusicianInstrument;
};
