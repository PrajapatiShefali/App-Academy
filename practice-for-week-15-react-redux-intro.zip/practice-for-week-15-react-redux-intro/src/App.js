import FruitComponent from './components/FruitComponent';

import './App.css';

function App() {
  return (
    <div>
      <h1>App Component</h1>
      <FruitComponent />
    </div>
  );
}

export default App;
