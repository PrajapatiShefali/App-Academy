// Instantiate Express and the application - DO NOT MODIFY
const express = require('express');
const app = express();

// Import environment variables in order to connect to database - DO NOT MODIFY
require('dotenv').config();
require('express-async-errors');


// Import the models used in these routes - DO NOT MODIFY
const { Cat, Toy, sequelize } = require('./db/models');
const { Op } = require("sequelize");


// Express using json - DO NOT MODIFY
app.use(express.json());




// STEP 1: Load the toys and find the count, min price, max price, and sum
app.get('/toys', async (req, res, next) => {

    // A. Create an `allToys` variable that returns all toys
    // Your code here
    let allToys=[];
    allToys=await Toy.findAll()
    // B. Create a `toysCount` variable that returns the total number of toy
    // records
    // Your code here
    // let toysCount=await Toy.findAll({
    //     include:[
    //         [
    //             sequelize.fn("COUNT", sequelize.col("id")), 
    //             "toyCount"
    //           ] 
    //     ]
    // });
    let toysCount=await Toy.count({});
    // C. Create a `toysMinPrice` variable that returns the minimum price of all
    // the toys
    // Your code here
    let toysMaxPrice=await Toy.max('price')
    // D. Create a `toysMaxPrice` variable that returns the maximum price of all
    // the toys
    // Your code here
    let toysMinPrice=await Toy.min('price')
    // // E. Create a `toysSumPrice` variable that returns the sum of all of
    // // the toy prices.
    // // Your code here
    let toysSumPrice=await Toy.sum('price')

    res.json({
        toysCount,
        toysMinPrice,
        toysMaxPrice,
        toysSumPrice,
        allToys
    });
});




// STEP 2a: Find a cat with their associated toys, and aggregate toy data
app.get('/cats/:id/toys', async (req, res, next) => {
    try {
      const catId = req.params.id;
  
      // Fetch aggregate data for the cat's toys
      const catToysAggregateData = await Toy.findAll({
        attributes: [
          [sequelize.fn('COUNT', sequelize.col('id')), 'toyCount'],
          [sequelize.fn('AVG', sequelize.col('price')), 'averageToyPrice'],
          [sequelize.fn('SUM', sequelize.col('price')), 'totalToyPrice']
        ],
        include: [
          {
            model: Cat,
            attributes: [],
             // No need to include Cat attributes
            where:{
                id:catId
            }
          }
        ],
        
        raw: true
      });
  
      // Fetch the cat and its associated toys
      const cat = await Cat.findByPk(catId, {
        include: {
          model: Toy
        }
      });
  
      if (!cat) {
        return res.status(404).json({ error: 'Cat not found' });
      }
  
      // Convert cat to JSON and add aggregate data
      const catData = cat.toJSON();
      if (catToysAggregateData.length > 0) {
        const aggregateData = catToysAggregateData[0];
        catData.toyCount = aggregateData.toyCount;
        catData.averageToyPrice = aggregateData.averageToyPrice;
        catData.totalToyPrice = aggregateData.totalToyPrice;
      } else {
        catData.toyCount = 0;
        catData.averageToyPrice = 0;
        catData.totalToyPrice = 0;
      }
  
      // Send response with formatted data
      res.json(catData);
    } catch (error) {
      next(error);
    }
  });


// BONUS STEP: Create an endpoint for GET /data-summary that includes a summary
// of all the aggregate data according to spec
// Your code here
app.get('/data-summary', async (req, res, next) => {
    try {
        // Query for total number of cats
        const totalNumberOfCats = await Cat.count();

        // Query for total number of toys
        const totalNumberOfToys = await Toy.count();

        // Query for toy summary
        const toySummary = await Toy.findAll({
            attributes: [
                [sequelize.fn('AVG', sequelize.col('price')), 'averagePriceOfAToy'],
                [sequelize.fn('SUM', sequelize.col('price')), 'totalPriceOfAllToys'],
                [sequelize.fn('MAX', sequelize.col('price')), 'maximumToyPrice'],
                [sequelize.fn('MIN', sequelize.col('price')), 'minimumToyPrice']
            ],
            raw: true
        });

        // Query for expensive toy summary
        const expensiveToySummary = await Toy.findAll({
            attributes: [
                [sequelize.fn('AVG', sequelize.col('price')), 'averagePriceOfAnExpensiveToy']
            ],
            where: {
                price: {
                    [Op.gt]: 55
                }
            },
            raw: true
        });

        // Respond with the formatted data
        res.json({
            totalNumberOfCats,
            totalNumberOfToys,
            toySummary: toySummary.length > 0 ? toySummary : [{}], // Ensure we always return an array
            expensiveToySummary: expensiveToySummary.length > 0 ? expensiveToySummary : [{}] // Ensure we always return an array
        });
    } catch (error) {
        next(error);
    }
});


// Root route - DO NOT MODIFY
app.get('/', (req, res) => {
    res.json({
        message: "API server is running"
    });
});

// Set port and listen for incoming requests - DO NOT MODIFY
const port = 5000;
app.listen(port, () => console.log('Server is listening on port', port));