import SeparatorTwo from "./SeparatorTwo";

const SeparatorOne = () => {
  return (
    <div className="sep-1">
      <SeparatorTwo />
    </div>
  );
};

export default SeparatorOne;
