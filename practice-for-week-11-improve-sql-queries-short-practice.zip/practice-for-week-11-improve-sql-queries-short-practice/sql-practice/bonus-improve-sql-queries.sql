----------
-- Step 0 - Create a Query 
----------
-- Query: Find a count of `toys` records that have a price greater than
    -- 55 and belong to a cat that has the color "Olive".

    -- Your code here
select count(toys.id)
from cats join cat_toys  
on cats.id=cat_toys.cat_id 
join toys on toys.id=cat_toys.toy_id
where toys.price>55 and cats.color like "Olive";
-- Paste your results below (as a comment):
--215



----------
-- Step 1 - Analyze the Query
----------
-- Query:
EXPLAIN QUERY PLAN
select count(toys.id)
from cats join cat_toys  
on cats.id=cat_toys.cat_id 
join toys on toys.id=cat_toys.toy_id
where toys.price>55 and cats.color like "Olive";
    -- Your code here

-- Paste your results below (as a comment):


-- What do your results mean?

    -- Was this a SEARCH or SCAN?


    -- What does that mean?


-- Run Time: real 0.005 user 0.015625 sys 0.000000
-- 0|0|1|SCAN TABLE cat_toys
-- 0|1|0|SEARCH TABLE cats USING INTEGER PRIMARY KEY (rowid=?)
-- 0|2|2|SEARCH TABLE toys USING INTEGER PRIMARY KEY (rowid=?)
-- Run Time: real 0.003 user 0.000000 sys 0.000000

----------
-- Step 2 - Time the Query to get a baseline
----------
-- Query (to be used in the sqlite CLI):

    -- Your code here

-- Paste your results below (as a comment):




----------
-- Step 3 - Add an index and analyze how the query is executing
----------
drop table if exists toys_count;
create table toys_count(count_toy INTEGER);
insert into toys_count 
select count(toys.id)
from cats join cat_toys  
on cats.id=cat_toys.cat_id 
join toys on toys.id=cat_toys.toy_id
where toys.price>55 and cats.color like "Olive";

-- Create index:
create index cat_toys_bonus_index on toys_count(count_toy);
    -- Your code here

-- Analyze Query:
    -- Your code here
EXPLAIN QUERY PLAN
select * from toys_count;
-- Paste your results below (as a comment):


-- Analyze Results:

    -- Is the new index being applied in this query?

-- 0|0|0|SCAN TABLE toys_count
-- Run Time: real 0.001 user 0.000000 sys 0.000000


----------
-- Step 4 - Re-time the query using the new index
----------
-- Query (to be used in the sqlite CLI):

    -- Your code here

-- Paste your results below (as a comment):


-- Analyze Results:
    -- Are you still getting the correct query results?


    -- Did the execution time improve (decrease)?


    -- Do you see any other opportunities for making this query more efficient?



---------------------------------
-- Notes From Further Exploration
---------------------------------
