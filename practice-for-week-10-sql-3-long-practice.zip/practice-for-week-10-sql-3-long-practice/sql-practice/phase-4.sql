-- Give "Red" the cat one of every toy the other cats have
-- Your code here
INSERT into toys (cat_id,name)
select (select id from cats where name like 'Red') as cat_id,name
from toys;

select * from toys;
-- Query spoiled cats reporting the most spoiled first
-- Your code here

select name
from  cats 
where id in (select cat_id
                from toys
                group by cat_id 
                order by count(name) desc 
                );

