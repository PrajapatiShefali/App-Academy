-- Find All the Toys for Hermione's cats
-- Your code here

select name 
from Toys join cat_owners
on cat_owners.cat_id=toys.cat_id
join owners on owners.id=cat_owners.owner_id 
where owners.first_name like 'Hermione';