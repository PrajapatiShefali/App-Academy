-- Find names of the cats whose owners are 
--both George Beatty and Melynda Abshire, or just George Beatty,
-- or just Melynda Abshire
-- Your code here

select cats.name
from owners join cat_owners 
on cat_owners.owner_id=owners.id
join cats on cats.id=cat_owners.cat_id
where (owners.first_name like 'George' 
and owners.last_name like 'Beatty') or 
(owners.first_name like 'Melynda' and owners.last_name like 'Abshire')
limit 2;